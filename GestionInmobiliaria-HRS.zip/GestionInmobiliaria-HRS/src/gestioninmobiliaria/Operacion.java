/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package gestioninmobiliaria;

/**
 *
 * @author DAW TARDE
 */
public enum Operacion {
    ALQUILER, VENTA, ALQUILER_CON_OPCION_A_VENTA
}
