/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gestioninmobiliaria;

import java.util.List;

/**
 *
 * @author Killer
 */
public interface Catalogo {

    /**
     * Añadimos el piso que entra por parámetro si la variable pos es -1, es
     * decir, que no encuentra la posicion del objeto ya que hemos utilizado
     * indexof, sino, saldra un mensaje de objeto resgistrado
     *
     * @param p
     */
    void addPiso(Piso p);

    int countPisos(String c);

    boolean existsHigherPrice(double p);

    String getDireccionConMenorPrecio();

    List<Piso> getPisos();

    void orderCatalog();

    /**
     * Quitamos un piso de la lista si ya existe
     *
     * @param p
     * @return
     */
    boolean removePiso(Piso p);

    List<Piso> returnCatalog(double p, double s);

    double returnSumaPrecios(int planta);

    void setPisos(List<Piso> pisos);

    void setPrecioPiso(double s, int p);

    void underPlant(int f);
    
}
