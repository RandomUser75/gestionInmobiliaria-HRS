/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninmobiliaria;

import java.util.Comparator;

/**
 *
 * @author Killer
 */
public class OrderBySuperficie implements Comparator<Piso>{
    public int compare(Piso p1, Piso p2){
        return Double.compare(p1.getSuperficie(), p2.getSuperficie());
    }
}
