/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninmobiliaria;

import static gestioninmobiliaria.Operacion.ALQUILER;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author killer
 */
public class CatalogoImpl implements Catalogo {

    private List<Piso> pisos = new ArrayList<>();

    @Override
    public List<Piso> getPisos() {
        return pisos;
    }

    @Override
    public void setPisos(List<Piso> pisos) {
        this.pisos = pisos;
    }

    public CatalogoImpl() {
    }

    /**
     * Ej 7 En este metodo pasaremos un string por parametro, lo convertimos a
     * tipo operacion y lo comparamos con la operacion del piso, si es igual,
     * sumara uno a una variable
     *
     * @param c
     * @return
     */
    @Override
    public int countPisos(String c) {
        int count = 0;
        if (c.equals("ALQUILER") || c.equals("alquiler") || c.equals("VENTA") || c.equals("venta")) {
            Operacion op = Operacion.valueOf(c.toUpperCase());
            for (Piso p : this.pisos) {
                if (p.getOperacion().equals(op)) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Ej 8 Añadimos el piso que entra por parámetro si la variable pos es -1,
     * es decir, que no encuentra la posicion del objeto ya que hemos utilizado
     * indexof, sino, saldra un mensaje de objeto resgistrado
     *
     * @param p
     */
    @Override
    public void addPiso(Piso p) {
        int pos = this.pisos.indexOf(p);
        if (pos == -1) {
            this.pisos.add(p);
            System.out.println("Añadido");
        } else {
            System.out.println("Piso ya registrado");
        }
    }

    /**
     * Ej 9 Quitamos un piso de la lista si ya existe
     *
     * @param p
     * @return
     */
    @Override
    public boolean removePiso(Piso p) {
        return this.pisos.remove(p);
    }

    /**
     * Ej 10 El precio de los pisos que esten en una planta pasada por parametro
     * se van a sumar
     *
     * @param planta
     * @return
     */
    @Override
    public double returnSumaPrecios(int planta) {

        double sum = 0;
        for (Piso p : this.pisos) {
            if (p.getFloor() == planta) {
                sum = sum + p.getPrecio();
            }
        }
        return sum;
    }

    /**
     * Ej 11
     *Creamos un comparador que ordenara los pisos con cociente ascendentemente y devolvemos el primer piso de la lista, es decir, el piso con menor cociente
     * @return
     */
    @Override
    public String getDireccionConMenorPrecio() {

        Collections.sort(this.pisos, new ComparePrice());
        return this.pisos.get(0).getDireccion();

    }

    /**
     * Ej 12 Pasamos por parametro un precio y una superficie, si hay algun piso
     * mayor que la superficie y menor que el precio, se va a añadir a una lista
     * que luego se va a mostrar
     *
     * @param p
     * @param s
     * @return
     */
    @Override
    public List<Piso> returnCatalog(double p, double s) {
        List<Piso> pisosPrecioYSuperficie = new ArrayList<>();
        for (Piso piso : this.pisos) {
            if (piso.getPrecio() < p && piso.getSuperficie() > s) {
                pisosPrecioYSuperficie.add(piso);
            }
        }
        return pisosPrecioYSuperficie;
    }

    /**
     * Ej 13 Mediante un comparador, ordenamos los pisos por superficie
     *
     * @return
     */
    @Override
    public void orderCatalog() {

        Collections.sort(this.pisos, new OrderBySuperficie());
        System.out.println(this.pisos);

    }

    /**
     * Ej 14
     *Mientras recorremos la lista, si se encuentra un precio menor que el parametro se detendra y devolvera true, sino, devolvera false
     * @param p
     * @return
     */
    @Override
    public boolean existsHigherPrice(double p) {

        for (Piso piso : this.pisos) {
            if (piso.getPrecio() < p) {
                return true;
            }
        }
        return false;

    }

    /**
     * Ej 15 Si la planta de un piso esta por debajo del parametro de entrada,
     * sumara uno a un contador, cuando termine, si el contador es igual al
     * tamaño de la lista, va a printear que todos los pisos estan por debajo,
     * sino, se rompera y devolvera que hay alguno por encima
     *
     * @param f
     * @return
     */
    @Override
    public void underPlant(int f) {
        int count = 0;
        for (Piso p : this.pisos) {
            if (p.getFloor() < f) {
                count++;
            } else {
                break;
            }
        }
        if (count == this.pisos.size()) {
            System.out.println("Pisos por debajo");
        } else {
            System.out.println("Pisos por encima");

        }
    }

    /**
     * Ej 16 Los pisos cuya superficie sea mayor a un parametro, su precio se
     * rebajara dependiendo del porcentaje introducido
     *
     * @param s
     * @param p
     */
    @Override
    public void setPrecioPiso(double s, int p) {
        boolean f=false;
        for (Piso piso : this.pisos) {
            if (piso.getSuperficie() > s) {
                piso.setPrecio(piso.getPrecio() * (p / 100));
                f=true;
            }
        }if (f) {
            System.out.println("Los pisos de superficie s se han rebajado correctamente" + this.pisos);
        }
    }
}
