/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninmobiliaria;

/**
 *
 * @author killer
 */
public class PisoImpl extends ViviendaImpl implements Piso{
    private int floor;
    private char door;
    
    @Override
    public int getFloor() {
        return floor;
    }

    @Override
    public char getDoor() {
        return door;
    }

    @Override
    public double getSuperficie() {
        return superficie;
    }

    @Override
    public double getPrecio() {
        return precio;
    }

    @Override
    public Operacion getOperacion() {
        return operacion;
    }

    @Override
    public String getDireccion() {
        return direccion;
    }

    @Override
    public double getREBAJA() {
        return REBAJA;
    }

    public void setSuperficie(double superficie) {
        this.superficie = superficie;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setOperacion(Operacion operacion) {
        this.operacion = operacion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
    public PisoImpl(String direccion, int floor, char door) {
        super(direccion);
        this.floor = floor;
        this.door = door;
    }
    
     public PisoImpl(int floor, char door, double superficie, double precio, Operacion operacion, String direccion) {
        super(superficie, precio, operacion, direccion);
        this.floor = floor;
        this.door = door;
    }
    @Override
    public int compareTo(Vivienda v){
        int n=0;
        n=super.compareTo(v);
        if (n==0) {
            Piso p=(Piso)v;
            n=Integer.compare(this.getFloor(), p.getFloor());
            if (n==0) {
                n=Integer.compare(this.getDoor(), p.getDoor());
            }
        }return n;
    }
   
    
}
