/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioninmobiliaria;

import java.util.Scanner;

/**
 *
 * @author Killer
 */
public class test {
    /**
     * Ej 18
     * En este metodo preguntaremos al usuario las opciones disponibles mediante un do while y dependiendo de la opcion que elija, se ejecutara uno u otro metodo
     * @param c 
     */
    public static void setMenu(Catalogo c) {
        int op = 0;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("1: Añadir nuevo piso\n"
                    + "2: Eliminar un piso\n"
                    + "3. Mostrar piso con el menor precio por superficie\n"
                    + "4. Rebajar pisos.\n"
                    + "5. Filtrar por precio y por superficie.\n"
                    + "6: Visualizar Catálogo. \n"
                    + "7: Salir del menú");
            op = sc.nextInt();
            switch (op) {
                case 1:
                    addPiso(c, sc);
                    break;
                case 2:
                    removePiso(c, sc);
                    break;

                case 3:
                    c.getDireccionConMenorPrecio();
                    break;

                case 4:
                    System.out.println("Introduce superficie");
                    double superficie = sc.nextDouble();
                    System.out.println("Introduce porcentaje");
                    int porcentaje = sc.nextInt();
                    c.setPrecioPiso(superficie, porcentaje);
                    break;

                case 5:
                    System.out.println("Introduce superficie");
                    double superficie2 = sc.nextDouble();
                    System.out.println("Introduce precio");
                    double precio = sc.nextDouble();
                    c.returnCatalog(superficie2, precio);
                    break;

                case 6:
                    System.out.println(c.getPisos());
                    break;

                case 7:
                    System.out.println("Menu cerrado");
                    break;
            }
        } while (op < 1 && op > 7);

    }
    /**
     * En este metodo preguntaremos cada atributo de un piso y se añadira a la lista. En el tipo de operacion, si se elige una opcion incorrecta se rompera el scanner
     * @param c
     * @param sc 
     */
    public static void addPiso(Catalogo c, Scanner sc) {
        System.out.println("Introduce planta");
        int floor = sc.nextInt();
        System.out.println("Introduce puerta");
        char door = (char) sc.nextInt();
        System.out.println("Introduce superficie");
        double superficie = sc.nextDouble();
        System.out.println("Introduce precio");
        double precio = sc.nextDouble();
        System.out.println("Introduce operacion:\n"
                + "1.Alquiler\n"
                + "2.Alquiler con venta\n"
                + "3.Venta");
        int num = sc.nextInt();
        Operacion op = checkOperacion(num);
        switch (num) {
            case 1, 2, 3:
                System.out.println("Introduce direccion");
                String direccion = sc.nextLine();
                Piso p = new PisoImpl(floor, door, superficie, precio, op, direccion);
                c.addPiso(p);
                System.out.println("Operacion realizada con exito");
                System.out.println(c.getPisos());
            default:
                break;
        }

    }
    /**
     * En este metodo quitaremos un piso de la lista preguntando cada atributo
     * @param c
     * @param sc 
     */
    public static void removePiso(Catalogo c, Scanner sc) {
        System.out.println("Introduce planta");
        int floor = sc.nextInt();
        System.out.println("Introduce puerta");
        char door = (char) sc.nextInt();
        System.out.println("Introduce superficie");
        double superficie = sc.nextDouble();
        System.out.println("Introduce precio");
        double precio = sc.nextDouble();
        System.out.println("Introduce operacion:\n"
                + "1.Alquiler\n"
                + "2.Alquiler con venta\n"
                + "3.Venta");
        int num = sc.nextInt();
        Operacion op = checkOperacion(num);
        switch (num) {
            case 1, 2, 3:
                System.out.println("Introduce direccion");
                String direccion = sc.nextLine();
                Piso p = new PisoImpl(floor, door, superficie, precio, op, direccion);
                boolean f = c.removePiso(p);
                if (f) {
                    System.out.println("Piso eliminado");
                } else {
                    System.out.println("Piso no encontrado");
                }
            default:
                break;
        }
    }
    
    public static Operacion checkOperacion(int num) {

        switch (num) {
            case 1:
                return Operacion.ALQUILER;
            case 2:
                return Operacion.ALQUILER_CON_OPCION_A_VENTA;
            case 3:
                return Operacion.VENTA;
            default:
                System.out.println("Elige una opcion valida");

        }
        return null;
    }
}
